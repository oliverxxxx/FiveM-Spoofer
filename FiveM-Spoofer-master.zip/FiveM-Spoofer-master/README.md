# FiveM-Spoofer 
// This will help you with unbanning yourself from FiveM 


### Updates
*16.9.2020 Added HardwareID spoofing.*

### Credits

[https://github.com/ImFrosher]
[https://github.com/rutkuli]
